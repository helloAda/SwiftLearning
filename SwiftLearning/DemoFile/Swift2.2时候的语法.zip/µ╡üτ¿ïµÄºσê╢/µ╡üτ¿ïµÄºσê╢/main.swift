//
//  main.swift
//  流程控制
//
//  Created by 黄铭达 on 16/8/11.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation

//分支结构

//var age = 30
//if age > 20{
//    print("大于20")
//}else{
//    print("小于20")
//}

// 不需要break 自动跳出 case至少一条语句 case标签后可以有多个值，用逗号隔开 还可以是一个范围或者元组 支持值绑定
//let score = "a"
//switch score{
//    case "A" , "a":
//    print("优秀")
//    case "B":
//    print("良好")
//    default:
//    print("其他")
//}
//使用fallthrough
//var num = 5
//var desc = "\(num)是"
//switch num {
//    case 2,3,5,7:
//    desc += "质数，而且还是"
//    fallthrough
//    default:
//    desc += "整数"
//}
//print(desc)


//case后面的条件为元组  _表示忽略这个值
//var point = (x: 1 , y: 1)
//switch point{
//    case(0 , 0):
//    print("(0 , 0)位于原点")
//    case(_ , 0):
//    print("(\(point.0) , 0)位于x轴上")
//    case (0..<Int.max , 0..<Int.max): //这里3个点会报错，还不清楚原因
//    print("(\(point.0) , \(point.1))位于第一象限")
//    default:
//    break
//}

//值绑定
//var point = (x: 1 , y: 1)
//switch point{
//    case(0 , 0):
//    print("(0 , 0)位于原点")
//    case(var a , 0):
//    print("该点在x轴上，x的值为\(a)")
//    case var (x , y) where x > 0 && y > 0 : //条件值绑定 满足条件才绑定
//    print("(\(x) , \(y))位于第一象限")
//    default:
//        break
//}



//循环结构

//for var count = 0; count < 10; count += 1{
//    
//} //这种c的风格在Swift以后的版本将消失。

//for count in 0 ..< 10{
//    print(count)
//}


//let base = 3
//let power = 10
//var answer = 1
//for _ in 1...power{
//    answer *= base
//}
//print(answer)


// 标签： 紧跟冒号的标示符 ，只有放在循环语句或switch 语句之前才有作用
outer: for i in 0 ..< 5{
    for j in 0 ..< 3{
        print("i的值为:\(i),j的值为:\(j)")
        if j == 1{
            break outer
        }
    }
}













