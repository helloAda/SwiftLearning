//
//  main.swift
//  运算符
//
//  Created by 黄铭达 on 16/8/11.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation

//赋值运算符
//var x = 3
//var y = 4

//var a: Int
//var b = a = 20//Swift赋值表达式是没有值的，不支持连续赋值

//算术运算符
//var c = 19 / 4
//print(c)

//var d = 2.5 / 1.2
//var f = 4.3 / 0.0
//print(d)
//print(f)

//var g = 5.2
//var h = -3.1
//var mod = g % h//结果正负取决于被除数的符号
//print(mod)

//var a = 5
//a += 1  //Switf 3 之后++被替代了
//var b = a + 6
//print(b)
//print(a)

//溢出运算符 &- &+  &* &/ &% 根据二进制执行计算的
//var willUnderflow = UInt8.min//UInt8.min最小值为0
//willUnderflow = willUnderflow &- 1
//print(willUnderflow)

//let a = 20
//let b = a &/ 0  //Xcode7中 好像这两个用不了。暂时不清楚 结果是都为0
//let c = a &% 0
//print(b)
//print(c)


//位运算符

/*  都是二进制计算
    &   按位与
    |   或
    ^   异或
    ~   取反
    <<  左位移
    >>  右位移
 */

//扩展后的赋值运算符
/*
    +=
    -=
    *=
    /=
    &=
    |=
 
 */

//区间运算符
//..< ...
//for a in 0...10{
//    print(a)
//}

//比较运算符 结果为BOOL
// === 特征相等运算符 !== 特征不等运算符
// var c = a === b 只有a和b指向的类型实例相同时，c为ture (即a b 都指向同一个对象)


//逻辑运算符
/*
    &&  与
    ||  或
    !   非
 */

//三目运算符 也可以嵌套
//var a = 5
//var b = 3
//var str = a > b ? "a 大于 b" : "a 小于 b"
//print(str)

//空合并运算符 a ?? b 将对可选类型a进行空判断，如果包含一个值就进行解封,否则就返回一个more值b
// 表达式a 必须是Optional类型 默认值b的类型必须要和a存储的类型保持一致
// 如果a为为空值(non-nil),那么值b将不回被估值

//let words = "hello"
//var say: String? //= "ada"
//var content = say ?? words
//print(content)



