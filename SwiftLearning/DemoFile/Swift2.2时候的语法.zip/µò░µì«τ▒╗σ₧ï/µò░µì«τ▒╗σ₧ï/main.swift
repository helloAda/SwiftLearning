//
//  main.swift
//  数据类型
//
//  Created by 黄铭达 on 16/8/10.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation

//变量 var ,常量 let
//标示符必须以字符(包括Unicode字符)、下划线_、没有符$开头，但不能以数字开头，不可以包含空格，不能使用关键字，长度没有限制
var str = "hello"
str += "World"

let 🐶 = "dog"

var `class` = 3  //如果关键字做为标示符，要加`` ，但是不推荐



//常量就是把 var -> let 声明一样
var name = "Lucky"

var age: Int

var string:String = "Smile"

var a = 20 , b: String , c = "Swift"

//print(name)






//整型：用Int就行
let oneMillion = 1_000_000 //可以增加下划线做为分隔符，也可以在数值前添加额外的值
let price = 0110
//print(oneMillion)

//整形之间转换必须是显示转换

var book1: Int16 = 100
var book2: Int32 = 30
//var totalPrice = book1 + book2//错误，因为类型不同
var totalPrice = Int32(book1) + book2
//print(totalPrice)







//浮点型
var w = 4.0 / 0.0 //inf 无穷大
var f = 0.0 / 0.0 //得到非数 nan
//print(w)
//print(f)

var width: Float = 2.1
var height: Double = 3.9
var area1 = width * Float(height)
var area2 = Int(width) * 4

//print(area1)
//print(area2)





//类型别名
typealias Age = UInt16
let myAge: Age = 10






//元组 swift 特有

var score = (140 , 140 , "优秀")

var health: (Int , Int , String)
health = (182 , 78 , "良好")//赋值时必须为所有的成员变量赋值
//print("health元组为: \(health)")
//print("health元组中的身高值为: \(health.0)")//根据下标输出元素

var test:(Int , (Int , String))//元组中可以包含元组
test = (10 , (100 , "Swift"))
//print("test元组中第二个元素的第一个元素为: \(test.1.0)")

//自定元组给定初值  Key-Valve
var score2 = (math: 140 , English: 140 , Assessment: "A")
var score3:(math: Int , English: Int , Assessment: String)
score3 = (math: 140 , English: 140 , Assessment: "A")//通过key赋值，顺序可以调换

//print(score3.math)







//可选类型 swift新特性

//任何已知类型后面紧跟?即可代表 可选类型 如 Int?
var str2 = "HelloAda"
//var num: Int = Int(str2)
var num: Int? = Int(str2)
//print(num) //nil表示 值缺失 是一个值

//强制解析：在变量或者常量后面添加!注意：必须可选类型的变量和常量确实有值的时候才解析成功
var num1: Int? = 10
var num2: Int? = 20

if num1 != nil  &&  num2 != nil{
    let sum = num1! + num2!
//    print(sum)
}else{
//    print("num1 或者 num2 为 nil，不能强制解析")
}

//可选绑定:可以用在if和while语句中来对可选类型的值进行判断并把值赋给一个常量或者变量。

var str3: String! = "Swift"
if var tem = str3 {
    print(tem)
}else{
    print("nil,不能解析")
}

//隐式解析可选类型：在已有类型的后面加!，适用于被赋值之后不回重新变为nil的变量

var possibleStr: String! = "ada"
print(possibleStr)


/*
 /*
 可以多层嵌套
 */
 */



