//
//  main.swift
//  类的构造和析构
//
//  Created by 黄铭达 on 16/9/9.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation


/*
 类的构造
 
 类的指定构造器和便利构造器
 类的构造器链
 两段式构造
 */


/*
 类的指定构造器和便利构造器
 
 1、一个类中至少有一个指定构造器，其必须负责初始化类中所有的实例存储属性
 2、便利构造器属于次要的、辅助性的构造器
 3、类中可以不定义便利构造器，便利构造器必须调用同一个类中的其他构造器完成初始化
 4、便利构造器语法格式
 convenience init(形参){
 
 }
 5、只有类中才有便利构造器的概念
 */

class Apple{
    var name: String!
    var weight: Double
    init(name: String, weight: Double){
        self.name = name
        self.weight = weight
    }
    //定义便利构造器，使用convenience修饰
    convenience init(n name: String, w weight: Double){
        self.init(name: name, weight: weight)
        self.name = name
    }
}

var apple1 = Apple(n: "红富士咯", w: 1.3)
var apple2 = Apple(name: "又是一个红富士", weight: 1.3)



/*
 类的构造器链
 Swift对构造器之间的调用链制订了如下3条规则
 1、子类构造器必须调用直接父类的指定构造器(如果有父类)
 2、便利构造器必须调用同一个类中的其他构造器
 3、便利构造器调用的构造器链的最终节点必须是指定的构造器
 
 简化记忆为：
 1、指定构造器总是向上代理(调用父类构造器)
 2、便利构造器总是必须横向代理(调用当前类的其他构造器)
 */


//class  Fruit{
//    var name: String
//    var weight: Double
//    init(name: String){
//        self.name = name
//        self.weight = 0.0
//    }
//    
//    //定义便利构造器
//    convenience init(name: String, weight: Double){
//        self.init(name: name)
//        self.weight = weight
//    }
//    //定义另一个便利构造器
//    convenience init(n name: String , w weight: Double){
//        self.init(name: name)
//    }
//}
//
//
//class Orange: Fruit{
//    var color: String
//    init(name: String, weight: Double, color: String) {
//        self.color = color
//        super.init(name: name)
//        self.weight = weight
//    }
//    
//    init(){
//        self.color = ""
//        super.init(name: "")
//        self.weight = 0.0
//    }
//    
//    convenience init(name: String, color: String) {
//        self.init(name: name, weight: 0.0, color: color)
//    }
//    
//    convenience init(n name: String, c color: String) {
//        self.init(name: name, color: color)
//    }
//}



/*
 两段式构造
 
 类的构造需要两个阶段
 第一阶段：
 1、程序调用子类的某个构造器
 2、为实例分配内存，此时实例的内存还没有被初始化；
 3、指定构造器确保子类定义的所有实例存储属性
 4、指定构造器将调用父类的构造器，完成父类定义的实例存储属性的初始化
 5、沿着调用父类构造器的构造器链一直往上执行，直到到达构造器链的最顶部
 
 第二阶段：
 1、沿着继承树往下，构造器此时可以修改实例属性，访问self，甚至可以调用实例方法
 2、最后，构造器链中的便利构造器都有机会定制实例和使用self
 
 
 
 安全检查
 1、指定构造器必须先初始化当前类中定义的实例存储属性，然后才能向上调用父类构造器
 2、指定构造器必须先向上调用父类构造器，然后才能对继承得到的属性赋值
 3、便利构造器必须先调用同一个类的其他构造器，然后才能对属性赋值
 4、构造器在第一阶段完成之前，不能调用实例方法，不能读取实例属性
 
 
 建议：为实例存储属性置顶初始值
 */





/*
 构造器的继承
 
 Swift的子类不会自动继承父类的构造器，若继承，则满足如下规则
 1、如果子类没有提供任何指定构造器，那么它将自动继承父类的所有指定构造器
 2、如果子类实现了父类所有的指定构造器，无论如何实现的，都将自动继承父类的所有便利构造器
 */

/*
 构造器的重写
 1、子类构造器重写了父类的指定构造器，必须添加override修饰符
 2、子类中定义的构造器只是与父类中便利构造器的形参列表、外部形参名相同，不算重写
 */

/*
 类与可能失败的构造器
 
 可能失败的构造器必须满足如下两个条件才能触发
 1、该类中的所有实例属性都已被赋初始值
 2、所有的构造器调用都已经被执行。
 */

//class User{
//    var name: String!
//    init?(name: String){
//        if name.isEmpty {
//            return nil
//        }
//        self.name = name
//    }
//}

/*
 可能失败的构造器的传播(调用)
 
 1、可能失败的构造器可以调用同一个类中的普通的构造器
 2、普通构造器不能调用同一个类中可能失败的构造器
 3、结构体中，普通构造器却可以调用同一个个结构体中可能失败的构造器
 */


class User{
    var name: String!
    init?(name: String){
        if name.isEmpty {
            return nil
        }
        self.name = name
    }
}

class Student: User {
    var grade: Int!
    init!(name: String, grade: Int){
        //调用父类可能失败的构造器
        super.init(name: name)
        print("---super.init(name:\(name))之后")
        //如果grade小于1，使用return nil 触发构造失败
        if grade < 1{
            return nil
        }
        self.grade = grade
    }
}

let s1 = Student(name: "Ada5", grade: 5)
print(s1.name,s1.grade)
let s2 = Student(name: "Ada0", grade:  0)
print(s2 == nil)
let s3 = Student(name: "", grade: 3)
print(s3 == nil)



/*
 重写可能失败的构造器
 
 1、子类可以用可能失败的构造器或者普通的构造器重写父类的可能失败的构造器
 2、子类的普通构造器不能向上调用父类的可能失败的构造器
 */






/*
 子类中必须包含的构造器和析构器
 
 Swift允许在父类构造器前添加required关键字，用于声明所有子类必须包含该required构造器
 父类中声明的required构造器既可是指定构造器,也可使便利构造器
 */





/*
 析构器
 
 析构器是一个名为deinit的函数，不需要使用func关键字，无参数和返回值。
 析构器是在实例释放之前有系统自定调用，不需要主动调用析构器
 子类自动继承父类的析构器，而且无论如何，子类析构器一定会调用父类析构器
 析构器可以访问该实例的所有实例存储属性，或者根据这些属性来关闭资源
 */













