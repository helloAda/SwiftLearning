//
//  main.swift
//  属性、方法、下标
//
//  Created by 黄铭达 on 16/9/5.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation



/* 存储属性

 存储属性:存储在类、结构体里的变量或者常量
 存储属性更分会:实例存储属性、类型存储属性
 所有的存储属性必需显示的指定初始值，在定义时或者构造器中指定
 可选类型的存储属性可以不指定初始值
 */

//结构体中实例存储属性的规则
/*1、程序为所有的实例存储属性指定了初始值，且没有构造器，则系统会提供两个构造器:一个无参数的构造器，和一个初始化所有实例存储属性的构造器
  2、没有初始值和构造器，系统提供一个初始化所有实例存储属性的构造器
  3、有构造器，则程序必须为结构体中的所有属性提供初始值
*/


//如上第二种
struct LengthRange {
    var start: Int
    //定义常量属性，可以不指定初始值
    let length: Int
}
var len = LengthRange(start: 9, length: 3)
//print(len.start , len.length)
len.start = 2

//结构体常量与实例属性
struct lengthRange2{
    var start: Int
    var length: Int
}
let len2 = lengthRange2(start: 1, length: 5)
//len2.length = 2 //不可以修改

//延迟存储属性:第一次被调用的时候才会被计算初始值的属性，用lazy修饰符 只能被定义成变量


/*
 计算属性(相当于OC或Java中的getter setter合成的属性)
 枚举、结构体、类都可以定义计算属性
 
 [修饰符] var 计算属性名:属性类型{
 get {
    get方法执行体，该方法一定要有返回值
 }
 set(形参名){
    set方法执行体，该方法一定不能有返回值
 }
 }
 */

class User{
    var first: String = ""
    var last:String = ""
//    定义计算属性
    var fullName: String{
        //定义计算属性的getter方法，该方法的返回值由first、last两个存储属性决定
//        get 可以省略
        get{
            return first + "-" + last
        }
        //定义计算属性的setter方法，该方法将负责改变该实例的first、last两个存储属性
        set(newValue){
            var names = newValue.componentsSeparatedByString("-")
            self.first = names[0]
            self.last = names[1]
        }
    }
    
    init(first: String, last: String){
        self.first = first
        self.last = last
    }
}

//let s = User(first:"黄",last: "铭达")
//print(s.fullName)
//s.fullName = "黄-铭达"
//print(s.first,s.last)
//只读属性，则无需set部分，可以省略get和花括号



/*
 属性观察者 用来观察属性变化
 1、可以监听除了延迟属性之外的所有存储属性(包括实例存储属性和类型存储属性)
 2、可通过重载方式为继承得到的属性(包括存储属性和计算属性) 添加属性观察者
 
 [修饰符] var 计算属性名:属性类型 = 初始值{
 willSet(newValue){
   属性即将被赋值之前自动调用的方法
 }
 didSet(oldValue){
   属性被赋值完成之后自动调用的方法
 }
 }
 
 注意：willSet和didSet后面的参数名都可以省略的
 */

//class Person{
////    定义存储属性
//    var name: String = ""{
//        willSet{
//            //
//            if (newValue.characters.count > 6) || (newValue.characters.count < 2) {
//                print("设置的名字\(newValue)不符合要求")
//            }else{
//                print("人名\(newValue)设置成功")
//            }
//        }
//        didSet{
//            print("人名设置完成,被修改的原名为:\(oldValue)")
//        }
//    }
//    var age: Int = 0{
//        willSet{
//            //
//            if (newValue > 100) || (newValue < 0) {
//                print("设置的年龄\(newValue)不符合要求")
//            }else{
//                print("年龄\(newValue)设置成功")
//            }
//        }
//        didSet{
//            print("年龄设置完成,被修改的原年龄为:\(oldValue)")
//        }
//    }
//}

//var p = Person()
//p.age = 999
//p.age = 23



/*
 方法
 
 1、定义方法需要在类型(枚举、结构体、类)里定义，不能独立定义  独立定义则为函数
 2、方法要么属于该类型本身，要么是该类型的一个实例
 3、不能独立执行方法，执行方法必须使用类型或实例作为调用者
 注意:枚举、结构体中方法使用static修饰，类中用class修饰，都属于类型方法 否则属于实例方法
 */

//将方法转换成函数
//class SomeClass{
//    func test(){
//        print("== test 方法 ==")
//    }
//    class func bar(msg:String){
//        print("==bar类型方法==,传入的参数为:\(msg)")
//    }
//}
//创建实例
//var sc = SomeClass()
////将sc的test方法分离成函数
//var f1:() -> () = sc.test
//
////将sc的bar方法分离成函数
//var f2: (String) -> Void = SomeClass.bar
//f1() //等价于sc.test()
//f2("ada")


//方法的外部形参名
//class Person{
//    var name: String
//    init(name: String){
//        self.name = name;
//    }
//    func eat(food: String, _ drink: String, _ cigarette: String){
//        print(self.name,food,drink,cigarette)
//    }
//}
//
//var p = Person(name:"Ada")
//p.eat("食物", "饮料", "烟")
//第一个没有外部参数名，其他的都有 不想要外部参数名 加添加_




/*
 值类型的可变方法
 */
//将mutating关键字放在func之前，即将该方法声明为可变方法

struct DRect {
    var x: Int
    var y: Int
    var width: Int
    var height: Int
    mutating func moveByX(x: Int, y: Int){
        self.x += x
        self.y += y
    }
}

var rect = DRect(x: 20, y: 12, width: 200, height: 300)
//调用mutating方法,该方法可以改变rect实例的存储属性
rect.moveByX(100, y: 90)
//print(rect.x,rect.y)
//注意 常量类型的结构体和枚举是不可变的




/*
 属性和方法的统一
 使用函数类型定义存储属性，并将函数或者闭包作为该属性的初始值，这个属性就成了方法
 */

func factorial(n: Int) -> Int {
    var result = 1
    for i in 1...n {
        result *= i
    }
    return result
}

struct SomeStruct {
    var info:() -> Void = {
        print("info方法")
    }
    //将全局函数作为fact存储属性的初始值
    static var fact: (Int) -> (Int) = factorial
}
var sc = SomeStruct()
//sc.info()
//使用闭包对sc对象的info赋值，相当于重新定义了sc的info方法
sc.info = {
    print("另一个闭包")
}
//sc.info()


var n = 6
print(SomeStruct.fact(6))

SomeStruct.fact = {
    var result = 1
    for i in 1...$0{
        result += i
    }
    return result
}

print(SomeStruct.fact(6))



/*
 下标
 1、所有的Swift类型(枚举、类、和结构体)都支持定义下标
 2、同一个类型可以定义多个下标
 3、通过下标的形参列表或者返回值类型类区别不同的下标
 4、同一类型中定义多个不同的下标被称为下标重载
 */

/*
 subscript(形参列表) -> 下标返回值类型{
    get {
    必须有返回值
 }
    set{
    不能有返回值
 }
 }
 
 形参列表：与函数的形参列表的用法基本相同，但是不支持指定外部参数和默认值
 下标的返回值类型：可以是任何有效的类型
 */

struct DRect2 {
    var x: Int
    var y: Int
    var width: Int
    var height: Int
    
//    定义下标，指定下标只接收一个Int类型的参数，下标的返回值类型为Int
    subscript(index: Int) -> Int{
        //get部分
        get{
            switch(index){
            case 0:
                return self.x
            case 1:
                return self.y
            case 2:
                return self.width
            case 3:
                return self.height
            default:
                print("不支持该索引")
                return 0
            }
        }
        //set部分
        set{
            switch(index){
            case 0:
                self.x = newValue
            case 1:
                self.y = newValue
            case 2:
                self.width = newValue
            case 3:
                self.height = newValue
            default:
                print("不支持该索引值")
            }
        }
    }
}

var rect2 = DRect2 (x: 20, y: 12, width: 200, height: 300)
//通过下标进行赋值
rect2[0] = 40
rect2[1] = 67

print(rect2[0],rect2[1])










