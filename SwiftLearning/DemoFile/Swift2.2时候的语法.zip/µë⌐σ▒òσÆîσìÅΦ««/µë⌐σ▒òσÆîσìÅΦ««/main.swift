//
//  main.swift
//  扩展和协议
//
//  Created by 黄铭达 on 16/9/8.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation



/*
 扩展
 
 添加属性，方法，可变方法、构造器、下标、嵌套类型
 可以使一个已有类型符合一个或者多个协议
 Swift的扩展与Objective-C的category类似，只是Swift中的扩展没有名字
 扩展并不是派生子类，因此不支持重写
 */

/*
 [修饰符]extension已有类型{
       // 添加新功能
 }
 
 注意：通过扩展为已有类型添加新的功能，那这个新功能在该类型的所有已有实例中都是可用的
 */

/*
 通过拓展可以让已有的类型遵守一个或者多个协议
 
 [修饰符]extension 已有类型：协议1，协议2{
 
 }
 */






/*
 扩展可以添加3种属性：
 类型存储属性
 实例计算属性
 类型计算属性
 */
extension String{
    static var data: [String:Any] = [:]
    var length: Int{
        get{
            return self.characters.count
        }
        set{
            //新设置的大于原有的长度，在字符串后面添加空格
            let originLength: Int = self.characters.count
            if newValue > originLength {
                for _ in 1...newValue - originLength{
                    self += "-"
                }
            }
            //新设置的小于原有的长度，将后面的截断
            else if newValue < originLength{
                var tmp = ""
                var count = 0
                for ch in self.characters {
                    tmp = "\(tmp)\(ch)"
                    count += 1
                    //如果已经拼接了newValue个字符，跳出循环
                    if count == newValue {
                        break
                    }
                }
                self = tmp
            }
        }
    }
}

//String.data["Swift"] = 89
//String.data["OC"] = 92
//print(String.data)
//
//var s = "jike.org"
//print(s.length)
//s.length = 5
//print(s)
//s.length = 10
//print(s)


// 扩展可以添加实例方法或者类型方法
extension String{
    func substringFromStart(start: Int, toEnd: Int) -> String {
        var count = 0
        var tmp = ""
        for ch in self.characters {
            if count >= start {
                tmp = "\(tmp)\(ch)"
            }
            if count >=  toEnd - 1 {
                break
            }
            count += 1
        }
        return tmp
    }
    static func valueOf(value:Bool) -> String{
        return "\(value)"
    }
}

var oldStr = "fhsdhryhtgfstegea"
var newStr = oldStr.substringFromStart(5, toEnd: 10)
print(newStr)

print(String.valueOf(true))
print(String.valueOf(false))


//通过扩展来添加可变方法
extension Array{
    mutating func retainAll(array: [Element],compartor:(Element, Element) -> Bool){
        var tmp = [Element]()
//        遍历当前数组种所有元素
        for ele in self {
//            遍历第二个数组的所有元素
            for target in array {
//                如果两个元素通过compartor比较返回ture
                if compartor(ele, target) {
                    tmp.append(ele)
                    break
                }
            }
        }
        self = tmp
    }
}

var books = ["iOS", "Android", "Swift", "Java", "Ruby"]
books.retainAll(["Android", "iOS", "C"]){
    return $0 == $1
}

print(books)



//通过扩展添加构造器
struct SomeStruct{
    var name: String
    var count: Int
    
}

extension SomeStruct{
    init(name: String){
        self.name = name
        self.count = 0
    }
    init(count: Int){
        self.count = count
        self.name = ""
    }
}
var sc1 = SomeStruct(name: "Ada",count: 10)
var sc2 = SomeStruct(name: "Ada2")
var sc3 = SomeStruct(count: 11)


//扩展添加下标
extension String{
    subscript(index: Int) -> String {
        get{
            if index > -1 && index < self.characters.count{
                var count = 0
                var result = ""
//                通过遍历搜索字符串内指定索引处的字符
                for ch in self.characters{
                    if count == index{
//                        将找到的字符转换为字符串
                        result = "\(ch)"
                    }
                    count += 1
                }
                return result
            }
            else{
                return ""
            }
        }
        set{
            var result = ""
            var count = 0
            for ch in self.characters{
                if count == index{
                    result += newValue
                }else{
                    result += "\(ch)"
                }
                count += 1
            }
            self = result
        }
    }
    
    //定义只读下标
    subscript(start: Int, end: Int) -> String{
        if start > -1 && start < self.characters.count && end > -1 && end < self.characters.count && start < end
        {
            var result = ""
            var count = 0
            for ch in self.characters{
                if count >= start && count <= end{
                    result.append(ch)
                }
                count += 1
            }
            return result
        }
        else{
            return ""
        }
    }
}

var s = "ada is a excellent coder!"
s[0] = "A"
print(s)
print(s[0, 2])


//通过扩展添加嵌套

extension String{
    enum numStr: String {
        case One = "1"
        case Two = "2"
        case Three = "3"
        case Four = "4"
    }
    
    static func judgeNumStr(s: String) -> numStr? {
        switch s {
        case "1":
            return .One
        default:
            return .Two
        }
    }
}

var s1: String.numStr? = String.judgeNumStr("1")
print(s1!)
var s2: String.numStr? = String.judgeNumStr("2")
print(s2!)




/*协议  完全类似与OC的
 1、Swift协议用于定义多个类型应该遵守的规范。
 2、协议定义了一种规范，不提供任何实现
 3、协议统一了属性名、方法、下标，但是协议并不提供任何实现
 4、语法格式:
 [修饰符] protocol 协议名：父协议1，父协议2，...{
 
 }
 */


/*
 协议语法说明
 修饰符：可以省略，也可以是private、internal、public之一
 协议名应与类名采用相同命名规则
 一个协议可以有多个直接父协议，但协议只能继承协议，不能继承类
 协议内容：指定协议实现者必须提供的那些功能，比如属性、方法、构造器和下标
 
 
 实现协议的语法
 struct 结构体：第一个协议，第二个协议，...{
 
 }
 
 Class 类名：SuperClass，第一个协议，第二个协议...{

 }
 
 协议指定的属性要求
 1、协议中定义属性要求的语法格式：
 class var 属性名：类型{get set}
 注：class可有可无，有则为类型属性
     get和set部分：只需写get set即可，无须提供实现 set可又可无
 */


protocol Strokable {
    var strokeWidth: Double {get set}
}

protocol Fullable {
    var fullColor: Color? {get set}
}

enum Color {
    case Red, Green, Blue, Yellow, Cyan
}

protocol HasArea: Fullable, Strokable {
    var area: Double {get}
    
}

protocol Mathable {
    static var pi: Double {get}
    static var e: Double {get}
}


//让Rect实现2个协议
struct Rect: HasArea,Mathable{
    var width: Double
    var height: Double
    init(width: Double, height: Double){
        self.width = width
        self.height = height
    }
    var fullColor: Color?
    var strokeWidth: Double = 0.0
    var area: Double{
        get{
            return width * height
        }
    }
    static var pi: Double = 3.131592653
    static var e: Double = 2.71828
}






