//
//  main.swift
//  枚举、类、结构体
//
//  Created by 黄铭达 on 16/9/5.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation

//Swift定义枚举的语法格式

//enum 枚举名 {
//    使用case 关键字列出所有枚举值
//    case <#case#>
//    枚举的其它成员
//}


//定义枚举
enum Season {
    case Spring
    case Summer
    case Fall
    case Winter
}
//使用一个case列举所有的值
enum Season1{
    case Spring, Summer, Fall, Winter
}

//使用枚举声明变量
var weather: Season
//weather = Season.Spring
weather = .Spring
//print(weather)


//枚举与Switch语句
//switch中的case没有覆盖枚举的所有值，必须添加default语句

//var chooseDay = Season.Fall
//switch(chooseDay){
//case .Spring:
//    print("春天")
//case .Fall:
//    print("秋天")
//default:
//    print("其它")
//}


//原始值
//整型的时候，Swift会自动推断前后的数值
enum Weekday: Int{
    case Mon, Tun, Wen = 3, Thur, Fri, Sat, Sun
}

//这种就要每个都赋值
enum Season3: Character {
    case Spring = "春"
    case Summer = "夏"
    case Fall = "秋"
    case Winter = "冬"
}

//rawValue 获取原始值
//print(Weekday.Fri.rawValue)

//根据原始值 获取枚举值
//init?(rawValue:)
//var mySeason = Season3(rawValue: "春")
//if mySeason != nil{
//    switch(mySeason!){
//    case .Spring:
//        print("春天")
//    default:
//        print("其他")
//    }
//}


//关联值

//enum Plant {
//    case Earth(weight: Double, name: String)
//    case Mars(desity: Double, name: String, weight: Double)
//    case Vens(Double , String)
//    case saturn
//    case Neptune
//}
//
//var p1 = Plant.Earth(weight: 1.0, name: "地球")
//var p2 = Plant.Vens(0.815, "金星")
//var p3 = Plant.Mars(desity: 3.95, name: "火星", weight: 0.1)
//
//switch(p3){
//case Plant.Earth(var weight, var name):
//    print("此行星的名字为:\(name),质量相当于\(weight)个地球")
//default:
//    print("其他")
//}


/*类和结构体*/
//结构体不支持继承，不支持定义析构器
//结构体是值类型，类是引用类型

/*
 定义类
 
 [修饰符]class 类名{
 零到多个构造器
 零到多个属性
 零到多个方法
 零到多个下标
 }
 修饰符可以是 private public internal final
 */

/*
 定义结构体
 
 [修饰符] struct 结构体名{
 修饰符可以是 private public internal
 }
 */

/*
 定义属性的语法
 [修饰符] var或者let 存储属性名:类型名字 ＝ 初始值(必须指定一个，可以在构造器指定)
 */

/*
 定义构造器语法
 [修饰符] init(形参列表){
     零到多条可执行语句组成的构造器执行体
 }
 */


/*
 定义方法的语法
 [修饰符] func 方法名(形参列表) -> 返回值类型{
    零到多条可执行语句
 }
 */


//定义一个person类

//class Person {
//    var name: String = "Jack"
//    var age: Int = 0
//    func hi(content: String){
//        print(content)
//    }
//}

//定义一个Dog结构体
//struct Dog{
//    var name: String
//    var age: Int
//    func run(){
//        print("\(name)在奔跑")
//    }
//    
//}

//创建Person类的实例
//var p: Person
//p = Person() //等价于 var p =  Person()
//print(p.name)
//p.hi("Hello Ada")
//创建Dog实例
//var dog = Dog(name: "旺财",age: 2)
//print(dog.name)
//dog.run()

//值类型与引用类型
//内存里的对象可以有多个引用，即多个引用变量指向同一个对象
//var p2 = p
//p2.name = "Rose"
//print(p2.name)

//值类型需要复制 引用类型不用
//var dog2 = dog
//dog2.name = "Rose"
//print(dog2.name)
//print(dog.name)


//引用类型的比较

//class User{
//    var name: String
//    var age: Int
//    init(name: String, age: Int){
//        self.name = name;
//        self.age = age;
//    }
//}
//
//var u1 = User(name: "Ada", age: 23)
//var u2 = User(name: "Ada", age: 23)
//
////=== !== 只能用于引用类型变量的比较，验证是否指向同一个实例
//print(u1 === u2)
//print(u1 !== u2)
//
//var u3 = u1
//print(u3 === u1)


/*
 self关键词
 1、构造器中的self 代表该构造器正在初始化的实例
 2、方法中的self 代表该方法的调用者
 */

class Dog{
    func jump(){
        print("jump")
    }
    func run(){
        self.jump()
        print("run")
    }
}

class Person{
    var name: String = ""
    var age: Int = 2
   //显示定义带参数的构造器
    init(name: String , age: Int){
        self.name = name;
        self.age = age;
    }
    func info(){
        print("名字:\(name),年龄:\(age)")
    }
}

var person = Person(name: "Ada", age: 23)
person.info()


/*
 结构体和类的选择
 
 1、结构体的主要目的是用于封装少量相关的简单数据
 2、如果需要在传递参数或者赋值时自动复制副本，使用结构体
 3、明确该类型无需继承另一个已有的类或者被其他类继续，使用结构体
 
 注意：大部分时候，程序应该自定义类而不是自定义结构体
 */
















