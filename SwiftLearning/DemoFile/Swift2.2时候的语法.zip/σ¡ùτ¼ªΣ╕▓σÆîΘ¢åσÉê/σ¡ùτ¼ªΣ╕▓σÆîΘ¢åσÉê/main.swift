//
//  main.swift
//  字符串和集合
//
//  Created by 黄铭达 on 16/8/24.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation


/*
 1、单个字符来指定字符常量，如 "A","9"
 2、转义字符表示特殊字符常量，如 "\n","\t"
 3、使用\u{n}的Unicode形式，n代表一个1~8位数的十六进制数
 4、必须用双引号包起来
 5、Swift中的每一个字符代表一个可扩展字母集
 */


//字符
var s:Character = "美"
var quote1 = "\'"//转义字符
var quote2 = "\u{22}"//unicode字符
//print("quote1 = \(quote1),quote2 = \(quote2)")

//使用Unicode形式定义4个字符
var diamond: Character = "\u{2666}"
var heart: Character = "\u{2663}"
var club: Character = "\u{2665}"
var spade: Character = "\u{2660}"
//print("\(diamond),\(heart),\(club),\(spade)")



/*          字符串        */
var str1 = "阿达"
//使用构造器创建  初始化字符串实例
var str2 = String()

//创建多个重复字符串 
//需要注意第二个参数的类型要写
var str3 = String(count : 4, repeatedValue: Character("a"))
var str4 = String(count : 4, repeatedValue: UnicodeScalar("🐶"))
//print("\(str3)----\(str4)")

//判断字符串是否为空
//print(str2.isEmpty)
//字符串拼接
var str5 = str3 + "阿达"
str3 += "ada"
//print(str3)
let char: Character = "!"
str3.append(char)
//print(str3)

//计算字符串的长度  oc中string.length和 Swift str3.utf16.count 是基于utf16的字符集计算 不是基于Unicode
//print("str3 has \(str3.characters.count) characters")

/* Swift中的字符串是否可以修改仅通过定义的是变量还是常量来决定*/
let str6 = "这个不可以改变"
let str7 = "这个不可以改变"
//if str6 == str7{
//    print("这两个字符串是相等的")
//}

var str8 = "这个可以改变"
//str6 = "改变试试" 直接报错
//str8 = "改变试试"
//print(str8)

//检查字符串是否拥有特定前缀/后缀，两个方法均需要以字符串作为参数传入并传出Boolean值
var food = ["Fruits : apple",
            "Fruits : orange",
            "Fruits : banana",
            "Vegetables : tomato",
            "Vegetables : potato"]
//for fru in food{
//    if fru.hasPrefix("Fruits"){ //前缀
//        print(fru)
//    }
//    if fru.hasSuffix("o"){ //后缀
//        print(fru)
//    }
//}

/*
 OC Foundation框架中的NSString是一个类 是一种引用类型 可以说是指针类型
 Swift中的字符串是一个结构体 是一种值类型  内容较少
 */





/*         数组           */

/*
 声明数组写法:
    第一种:Array<Type> , 如Array<Int>
    第二种:[type] , 如 [String]
 */

var myArr = Array<String>() //创建空数组，并赋值给myArray
var num = Array<Int>(count: 3 ,repeatedValue: 1)
//print(num)

var arr :[Int] = [1, 2, 3]
//print(arr)

//使用构造语法来创建一个由特定数据类型构成的空数组
var someInts = [Int]()

var threeDoubles = [Double](count: 3, repeatedValue : 0.0)
//print(someInts,threeDoubles)

var food1 = ["apple", "orange"]

//print(food1[1])
//print(food1.count)


var shoppingList = ["Eggs", 123 , true]
for item in shoppingList{
//    print(item)
}

for fruit in food1{
//    fruit = "good"  //错误遍历出来的 默认是let
//    print(fruit)
}



//数组可变性
//添加元素
food1.append("append")
//print(food1)

food1 += ["edafvsffg","grsgrs"]
//print(food1)

food1[0...2] = ["a","b"]
//print(food1)

//不能使用下标语法在数组尾部添加新项，调用insert(atIndex:)方法来在某个具体索引值之前添加数据项

food1.insert("c", atIndex: 2)
//print(food1)

//使用removeAtIndex方法来移除数据中的某一项
food1.removeAtIndex(3)
//print(food1)
//删除最后一项使用removeLast
food1.removeLast()
//print(food1)
//删除所有元素，参数为是否保留数据缓冲，默认是false
food1.removeAll()
//food1.removeAll(keepCapacity: true)
//print(food1)



/*        字典         */

/*
    Dictionary<keyType,valueType>
    [KeyType:VlueType]
 */

// 声明字典
var dic :Dictionary<String , String>
var scores:[String:Int]

//创建字典
dic =  Dictionary<String , String>()
scores = Dictionary<String , Int>(minimumCapacity: 5)//最小容量
var emptyDic:[String : Double] = [:]//空字典
//print(emptyDic.isEmpty)

//通过常量或者变量决定字典是否可变
var person = ["age" : "18" ,
              "name" : "Ada",
              "high" : "199"];
//print(person["age"]) //可选类型 要强制解析
//print(person["weight"])//不存在的key返回为nil
person["name"] = "Hello"
person["weight"] = "90"
//print(person)


var height:String? = person["high"]
if height != nil {
//    print(height!)
}

//updateValue(forKey:)方法在这个键不存在对应值的时候设置值或者存在时更新已存在的值。这个方法返回更新值之前的原值

if let oldName = person.updateValue("HelloAda", forKey: "name"){
//    print("原来的名字\(oldName)")
}
//print(person)


//遍历
for (key,value) in person{
//    print("\(key) : \(value)")
}

//removeValueForKey方法也可以用来在字典中移除键值对
person.removeValueForKey("name")
//print(person)

let keyArr = [String](person.keys)
let valuesArr = [String](person.values)
print(keyArr)
print(valuesArr)






