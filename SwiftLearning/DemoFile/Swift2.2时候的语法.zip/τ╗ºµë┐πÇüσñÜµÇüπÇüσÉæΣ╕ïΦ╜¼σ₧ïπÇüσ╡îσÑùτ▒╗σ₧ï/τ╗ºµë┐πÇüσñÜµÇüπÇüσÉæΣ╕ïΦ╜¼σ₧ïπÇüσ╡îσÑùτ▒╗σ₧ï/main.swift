//
//  main.swift
//  继承、多态、向下转型、嵌套类型
//
//  Created by 黄铭达 on 16/9/7.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation


/*
 继承
 
 重写父类的方法
 重写父类的属性
 重写属性观察者
 重写父类的下标
 使用final防止重写
 
 继承的特点
 1、单继承，每个子类只有一个直接父类
 2、子类继承父类，可以获得父类的属性、方法、下标，也可以进行重写
 3、Swift的类并不是从一个通用的积累继承而来的。
 4、override修饰被重写的部分
 5、final修饰的类不能被继承，属性、方法和下标不能被重写
 */


class fruit{
    var weight = 0.0
    func info() {
        print("水果重\(weight)")
    }
}

class Apple: fruit {
    var name: String!
    func taste() {
        print(name)
    }
    
}

var a = Apple()
a.weight = 56
a.name = "苹果"
//a.taste()
//a.info()


//重写父类的方法
class Bird{
    func fly(){
        print("父类")
    }
}

class Ostrich: Bird {
    override func fly() {
        print("子类")
    }
}


//var ostrich = Ostrich()
//ostrich.fly()


//重写父类的下标

class Base{
    subscript(index: Int) -> Int{
        get{
            print("父类的下标的get方法")
            return index + 10
        }
    }
    
}


class Sub: Base {
//    重写父类的下标
    override subscript(index: Int) -> Int{
        get{
            print("重写后的下标的get方法")
            print("通过super访问被重写之前的下标:\(super[index]))")
            return index * index
        }
        set{
            print("重写后的下标set方法，传入的参数值为：\(newValue)")
        }
    }
}

//var base = Base()
//print(base[8])
//var sub = Sub()
//print(sub[7])
//sub[7] = 90



//重写父类的属性
class Car{
    var speed: Double = 0
    
}

class MyCar: Car {
    override var speed: Double{
        get{
            print("这是被重写的属性")
            return super.speed
        }
        set{
            super.speed = newValue * newValue
        }
    }
}

//var myCar = MyCar()
//myCar.speed = 20.0
//print(myCar.speed)


//重写属性观察者
//class Game{
//    var number: Double = 0
//}
//
//class MyGame: Game {
//    override var number: Double{
//        didSet{
////            属性值被修改完成后，将会自动执行该方法
//            print("之前的值\(oldValue)")
//            super.number *= number
//        }
//    }
//}

//var myGame = MyGame()
//myGame.number = 100
//print(myGame.number)


/*
 final关键词防止重写
 */

final class Game{
    var number: Double = 0
}

////会报错了 不能重写
//class MyGame: Game {
//    override var number: Double{
//        didSet{
//            //            属性值被修改完成后，将会自动执行该方法
//            print("之前的值\(oldValue)")
//            super.number *= number
//        }
//    }
//}





/*--------------多态-------------------*/

/*
 Swift引用变量有两个类型:编译时类型、运行时类型
 编译时类型由声明该变量时使用类型决定
 运行时类型由实际赋给该变量的实例决定
 
 多态：相同类型的变量，调用同一个方法时呈现出多种不同的行为特征
 */

class BaseClass{
    func base(){
        print("父类普通方法")
    }
    func test(){
        print("父类的测试方法")
    }
}

class SubClass: BaseClass {
    func sub(){
        print("子类的普通方法")
    }
    
    override func test() {
        print("子类覆盖父类的方法")
    }
}

//let bc: BaseClass = SubClass()
//bc.base()
//bc.test()
////bc.sub()会报错 因为BaseClass没有这个方法



/*
 使用is运算符检查类型 返回值为布尔类型
 前一个操作数是一个引用类型变量，后一个操作数是一个类
 运算符前面的操作数的编译类型要么与后面的类相同，要么具有继承关系，否则编译报错
*/


@objc protocol TestProtocol{}
let hello: NSObject = "Hello"
//print(hello is NSString)
//print(hello is NSDate)
//print(hello is TestProtocol)

let str: NSString = "Hello"
//print(str is NSDate) //编译错误 上面第三点




/*
 向下转型
 
 注 向上转型：把一个子类实例直接赋给一个父类的引用变量、不用任何类型转换
 
 引用变量只能调用其编译时类型的方法，强制转换为其实际类型，可以调用运行时类型的方法，这种强制转换为向下转换
 向下转型运算符：
 1、as:强制将运算符前面的引用变量转换为后面的类型
 2、as?可选形式的向下转换
 
 向下转换职能在具有继承关系的两个类型之间进行
 */

let obj: NSObject = "Hello"
let objStr: NSString = obj as! NSString
//print(objStr)

//编译类型为NSObject， 实际类型为NSNumber
let objInt: NSObject = 5
//编译类型是有继承关系的，但是运行时没有， 所以编译不报错，运行报错
//let str1: NSString = objInt as! NSString



//let s: NSString = "Swift"
//编译时没有关系，会报错
//let it: NSNumber = s as! NSNumber

if objInt is NSString{
    let str: NSString = objInt as! NSString
    print(str)
}

/*
 嵌套类型
 
 在一个类型的内部定义另一个类型
 Swift的枚举、类、结构体都可以定义嵌套类型
 Swift的嵌套类型支持多级嵌套
 嵌套类型不允许使用static或者class修饰
*/

//使用嵌套类型时 需要以被嵌套类型的名字为前缀



