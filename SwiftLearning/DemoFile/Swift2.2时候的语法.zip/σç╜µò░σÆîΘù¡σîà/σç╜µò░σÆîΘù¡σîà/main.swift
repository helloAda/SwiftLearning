//
//  main.swift
//  函数和闭包
//
//  Created by 黄铭达 on 16/9/1.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation

/*
 函数 
 定义函数的语法格式
 func 函数名(形参列表) ->返回值类型{
    //可执行语句组成的函数
 }
 */

//定义和调用函数
//func sayHello(personName: String) -> String{
//    return "Hello , " + personName + "!"
//}
//print(sayHello("Ada"))

//函数形参
//func max(x: Int , y: Int) -> Int{
//    return x > y ? x : y
//}
//print(max(10,y: 9))

//没有参数的函数，小括号必须有

//func sayHelloAda() -> String {
//    return "Hello Ada!"
//}
//print(sayHelloAda())


//局部参数 width,height 不能在调用函数时使用
//func area(width: Double , _ height: Double) -> Double{
//    return width * height
//}
//print(area(2.4, 3.4))
//不加下划线，第二个参数也算外部参数

//外部参数名 局部参数名:形参类型
//func area(宽 width: Double , 高 height: Double) -> Double{
//    return width * height
//}
//print(area(宽: 2.0, 高: 3.0))


//可变参数 :在参数类型后面添加...表示该参数可以接受多个参数值

func sum(numbers: Int...) -> Int {
    var total: Int = 0;
    for num in numbers {
        total += num
    }
    return total
}
//print(sum(1,2,3,4,5,6,7,8,9,10))

//默认参数
func sayHi(msg: String , _ name: String = "Lily") -> Void {
    print("\(name), \(msg)")
}
//sayHi("哈哈")
//sayHi("haha","ada")

// 既有可变又有默认的 可变参数放在最后面，默认参数只能出线在次后面

//常量形参，变量形参 Swift3中没有变量形参了所以只能把常量形参赋值给变量在使用
func factorial(number: Int) -> Int {
    var result = 1
    var counter = number
    while counter > 1 {
        result *= counter
        counter -= 1
    }
    return result
}
//print(factorial(2))


// In-Out形参

func swap(inout a: Int , inout b: Int){
   let tmp = a
    a = b
    b = tmp
}

var a: Int = 1
var b: Int = 2
swap(&a, b: &b)
//print(a, b)

/*
 在Swift中除了类、函数、闭包是引用类型 其他绝大部份都是值类型
 值类型的参数在传入函数内部的时候传入的都是副本，无法对他产生影响
 in-out就是强制传入它的指针
 
 1、只能传入变量作为实参
 2、输入输出参数不能带有默认值
 3、如果用了关键字，inout标记了一个参数，这个参数不能在用var let标记了
 */



//返回值

//没有指定返回类型的函数总返回void 在Swift中 void可以理解为空元组
func sayHi2(){
    print("Welcome")
}
//sayHi2()

//多个返回值
func area(width: Double , height: Double) -> (Double , Double){
    let s = width * height
    let c = (width + height) * 2
    return(s , c)
}
//print(area(3.1, height: 3.4))


/*    函数的类型      */

func add(a: Int , b: Int) -> Int {
    return a + b
}
func mul(a: Int , b: Int) -> Int {
    return a * b
}
//函数作为变量
//var mathFunction: (Int, Int) -> Int = mul
//print(mathFunction(2,3))

//函数类型作为参数类型
func printMathResult(mathFunction:(Int ,Int) -> Int, a: Int, b: Int){
    print(mathFunction(a,b))
}

//print(printMathResult(mul, a: 3, b: 5))

//函数类型作为返回值类型

//func squre(num: Int) -> Int {
//    return num * num
//}
//func cube(num: Int) -> Int {
//    return num * num  * num
//}
//
//func getMathFunc(type: String) -> (Int) -> Int {
//    switch type {
//    case "squre":
//        return squre
//    default:
//        return cube
//    }
//}
//
//var mathFunc = getMathFunc("squre")
//print(mathFunc(3))


//函数的重载
func test(){
    print("无参数的test()函数")
}

func test(msg: String){
    print("重载的test()函数\(msg)")
}

func test(msg: String) -> String {
    print("重载的test()函数\(msg),带返回值")
    return "test"
}

func test(msg msg:String){
    print("重载的test()函数,外部参数为\(msg)")
}
//test()
//var result: Void = test(msg: "阿达")
//var result1: String = test("阿达")
//var result2: Void = test("阿达")

//仅有局部参数名 不同 不算重载
//func test(message: String){
//    print("这个不算重载")
//}


/*     闭包         */

//嵌套函数
//func mainMathFunc(type: String) -> (Int) -> (Int){
//    func squre(num: Int) -> Int{
//        return num * num
//    }
//    func cube(num: Int) -> Int{
//        return num * num * num
//    }
//    switch type {
//    case "squre":
//        return squre
//    default:
//        return cube
//    }
//}
//
//var mathFunc = mainMathFunc("squre")
//print(mathFunc(4))




//闭包表达式
/*
 {(形参列表) -> 返回值类型 in
            可执行
 }
 */

//func mainMathFunc(type: String) -> (Int) -> (Int){
//    func squre(num: Int) -> Int{
//        return num * num
//    }
//    func cube(num: Int) -> Int{
//        return num * num * num
//    }
//    switch type {
//    case "squre":
//        return {(num: Int) -> Int in
//            return num * num
//        }
//    default:
//        return {(num: Int) -> Int in
//            return num * num * num
//        }
//    }
//}
//
//var mathFunc = mainMathFunc("squre")
//print(mathFunc(5))


/*       利用上下文推断类型      */
//var squre: (Int) -> Int = {(num) in return num * num}
//print(squre(3))
//可以省略小括号
//var squre: (Int) -> Int = {num in return num * num}
//print(squre(3))
//如果闭包表达式的执行体只有一行 而且这行代码的返回值可以作为闭包表达式的返回值 也可以省略return 闭包的形参名也可以省略 省略形参名，通过$0 $1 来采用第一个第二个参数
var squre: (Int) -> Int = { $0 * $0 }
print(squre(3))


var result: Int = {
    var result = 1
    for i in 1...$1{
        result *= $0
    }
    return result
}(4,3)
print(result)



//尾随闭包


func someFunction(num: Int ,fn:(Int) -> Int){
    //执行代码
}
//普通写法
someFunction(20,fn: {(Int) -> Int in return 10})
//尾随闭包形式
someFunction(20){(Int) -> Int in return 10}



//捕获上下文中的变量或者常量
func makeArr(ele: String) -> () -> [String]{
    //创建一个不包含任何元素的数组
    var arr: [String] = []
    func addElement() -> [String]{
        arr.append(ele)
        return arr
    }
    return addElement
}

//闭包是引用类型，函数也是




