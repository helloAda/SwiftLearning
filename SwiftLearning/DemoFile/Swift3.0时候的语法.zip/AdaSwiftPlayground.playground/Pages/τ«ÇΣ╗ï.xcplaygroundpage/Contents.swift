


/*
    由于Swift的语法变化太快
    写下这个playround
    一是为了记录自己学习的Swift语法
    二是为了在Swift有语法变化时，能很快的了解到新的语法
 
    ------2016.9  黄铭达
 */

//注意：请尽量在固态硬盘下跑Playground 否则运行速度太慢


import UIKit

var str = "Hello, playground"
