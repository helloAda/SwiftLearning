//
//  main.swift
//  可选链、类型属性和方法、构造器
//
//  Created by 黄铭达 on 16/9/6.
//  Copyright © 2016年 黄铭达. All rights reserved.
//

import Foundation


//回顾 可选类型  在原有类型后面添加？，需要强制解析
//             在原有类型后面添加！，不需要强制解析(隐式解析)

/*
 可选链
 1、可选链用于处理可选类型的属性、方法和下标
 2、使用可选链代替强制解析
 3、调用方法
 4、调用下标
 */

//创建3个关联类
class Customer{
    var name = ""
    var emp: Employee?
    init(name: String){
        self.name = name;
    }
//    模拟员工数据
    let employee = [
        Employee(name:"张三", title: "小弟"),
        Employee(name:"李四", title: "小弟"),
        Employee(name:"王五", title: "小弟"),
        Employee(name:"赵六", title: "小弟"),
                    ]
    func findEmp(empName: String) -> Employee! {
        for emp in employee {
            if emp.name == empName {
                return emp
            }
        }
        return nil
    }
}

class Company{
    var name = ""
    var addr = ""
    init(name: String , addr: String){
        self.name = name
        self.addr = addr
    }
}

class Employee{
    var name = "Lily"
    var title = "行政"
    var company: Company!
    init(name: String , title: String){
        self.name = name
        self.title = title
    }
    func info(){
        print("\(self.name)\(self.title)")
    }
}

//第一种
//var c = Customer(name: "CAda")
//var emp = Employee(name: "EAda", title: "Coder")
//c.emp = emp
//emp.company = Company(name: "LILANZ", addr: "JinJiang")
//
//print(c.name, c.emp!.company.name)


//第二种
var c2 = Customer(name:"CAda")
c2.emp = Employee(name:"EAda" , title: "老板")
//print(c2.name,c2.emp!.company.name)
////如果没赋值会崩溃 所以需要用可选链访问属性

//使用可选链访问属性 将可选类型的！换成？即使是隐式解析后面也要添加?号
//第一种改变成
//print(c.name, c.emp?.company?.name)
//第二种改变成
//print(c2.name,c2.emp?.company?.name)


//第三种
var c3 = Customer(name: "Ada")
//print(c3.name ,c3.emp?.company?.name)

/*
 1、可选链访问方式：将强制解析的感叹号换成？，在隐式解析的后面也添加？后缀
 2、可选链会自动判断程序访问的关联实例是否为nil
 */


//使用可选链调用方法
//c3.findEmp("张三")?.info()



//使用可选链访问下标
var dic = [Int : Customer]()
dic[1] = Customer(name: "Ada")
dic[2] = Customer(name: "Ada7")


//dic[1]?.findEmp("李四")?.info()
//dic[4]?.findEmp("王五")?.info()//因为不存在所以不会执行方法




/*
 类型属性 和类型方法
 
 Swift的类型中可以定义5种成员:属性、方法、下标、构造器和嵌套类型
 属性有类型属性和实例属性
 方法有类型方法和实例方法
 
 static:在枚举、结构体种修饰的属性、方法 为类型属性和方法
 class:在类中修饰的属性、方法 为类型属性和方法
 */


//值类型的类型属性

enum Season {
    // 为枚举定义类型存储属性，使用可选类型，系统将其初始化为nil
    static var desc : String?
    // 为枚举定义类型存储属性，且声明为常量
    static let name = "季节"
    static var info: String{
        get{
            return desc!
        }
        set{
            print(newValue)
        }
    }
}

//对Season枚举的类型属性赋值
//Season.desc = "季节类"
//print(Season.name)
//Season.info = "新的info"
//print(Season.info)

//结构体可以包含实例计算属性，不能包含实例存储属性
struct DRange{
//    为结构体定义类型存储属性，使用可选类型，系统将其初始化为nil
    static var desc: String?
//    为结构提定义类型存储属性，且声明为常量
    static let maxWidth = 10000
    static let maxHeight = 40000
    
    static var maxArea: Int{
        return maxWidth * maxHeight
    }
}

DRange.desc = "范围"
//print(DRange.desc!)
//print(DRange.maxHeight)
//print(DRange.maxWidth)
//print(DRange.maxArea)


//类的类型属性
class  User{
    class var nameMaxLength: Int{
        get{
            return 24
        }
        set{
            print(newValue)
        }
    }
}

//print(User.nameMaxLength)
//User.nameMaxLength = 20

//类中不可以定义类型存储属性，只能包含类型计算属性


//值类型的类型方法

enum Season2 {
    // 为枚举定义类型存储属性，使用可选类型，系统将其初始化为nil
    static var desc : String?
    // 为枚举定义类型存储属性，且声明为常量
    static let name = "季节"
    static func info() {
        print(name)
    }
    
    //定义带一个参数的类型方法
    static func setDesc(desc: String){
        self.desc = desc
    }
}
//Season2.info()
//Season2.setDesc("季节")
//print(Season2.desc)

//类的类型方法

class Math{
//    类不允许定义类型存储属性，使用类型计算属性代替
    class var pi: Double{
        return 3.141592653
    }
    class func abs(value: Double) -> Double {
        return value < 0 ? -value : value
    }
    // 定义类型方法，取消第二个形参的外部参数名
    class func pow(base: Double, _ exponent:Int) -> Double{
        var result = 1.0
        for _ in 1...exponent {
            result *= base
        }
        return result
    }
    //定义类型方法，类型方法可通过self 引用
    class func degree2Radian(degree: Double) -> Double{
        return degree * self.pi / 180
    }
}
//print(Math.pi)
//print(Math.pow(2, 4))
//print(Math.degree2Radian(1.57))
//print(Math.degree2Radian(45))


/*
 构造器
 
 1、Swift的构造器构造出来的实例由系统隐式返回
 2、构造器的作用完成每个类、结构体中实例存储属性的初始化
 3、为实例存储舒心赋初始值的时机：
    定义实例存储属性时指定初始值
    在构造器中为实例存储属性置顶初始值
 */

/*
 实例存储属性的初始化分类
 
 定义实例存储属性时显示指定了初始值
 实例存储属性的类型为可选类型
 系统提供的默认构造器为实例存储属性分配初始值
 显示提供的构造器为实例存储属性分配初始值
 */

/*
 类和结构体的构造器
 
 Swift只为类提供一个无参数的构造器
 Swift为结构体提供两个构造器：无参数的构造器和初始化所有实例存储属性的构造器
 */

/*
 可能失败的构造器
 有时候枚举、结构体、类的构造器 可能不能成功的返回实例 需要用到
 
 1、可能失败的构造器使用init? init!关键字进行定义
 2、在构造器执行体中使用return nil来表示构造器失败
 3、Swift不允许定义两个相同形参列表的构造器。即使一个是可能失败的构造器，一个是普通的构造器也不行
 */

//构造器的外部参数名
struct DPoint{
    var left: Int = 0
    var top: Int = 0
//    定义带两个参数的构造器，并为第二个构造器参数显示指定外部形参名
    init (left: Int , y top: Int){
        self.left = left
        self.top = top
    }
}

//第一个形参的外部参数名与局部形参名相同
//第二个形参的外婆参数名使用显式指定的形参名
var p = DPoint(left: 20 , y: 12)

//取消构造器的外部参数名就是加 _ 在参数名前面

//在构造器中常量属性是可以修改的  注意：现在这个版本好像不能修改了把100去掉才可以
//class User1{
//    let maxAge: Int
//    var name: String
//    init (maxAge: Int, name: String){
//        self.maxAge = maxAge
//        print(self.maxAge)
//        self.name = name
//    }
//}


//使用闭包或函数为属性设置初始值
struct ClosureInit{
//    使用闭包对test实例存储属性执行初始化
    var test: Int = {
        var date = NSDate()
        var gregorian = NSCalendar.currentCalendar()
//        定义一个时间字段的旗标，指定将会获取指定月
        var unitFlags = NSCalendarUnit.Month
        var comp = gregorian.components(unitFlags, fromDate: date)
//        获取当前的月份
        var month = Int(comp.month)
        return month
    }()
    
}

//var ci = ClosureInit()
//print(ci.test)




//值类型的构造器重载

//struct ConstructorOverload {
//    var name: String?
//    var amount: Int?
////    提供无参数构造器
//    init(){
//        
//    }
////    提供两个参数的构造器来完成构造过程
//    init(name: String, amount: Int){
//        self.name = name
//        self.amount = amount
//    }
//}
//
//
////通过无参数构造器创建ConstructorOverload实例
//var oc1 = ConstructorOverload()
//
////通过有参数构造器创建的ConstructorOverload实例
//var oc2 = ConstructorOverload(name: "Ada", amount: 10)
//print(oc1.name,oc1.amount)
//print(oc2.name,oc2.amount)


/*
 构造器代理： 在定义构造器时，通过self.init(实参)调用其他构造器来完成实例的部分构造过程
 
 简单来说就是在一个构造器中调用那一个构造器方法
 */

struct Apple
{
    var name: String
    var color: String
    var weight: Double!
    init(_ name: String , _ color:String)
    {
        self.name = name
        self.color = color
    }
    // 两个参数的构造器
    init(name: String , color:String)
    {
        self.init(name , color)  // 构造器代理
    }
    // 为构造器显式指定外部形参名
    init(appleName n: String , appleColor c:String)
    {
//        		name = "临时值" // 这行代码将导致错误
        self.init(n , c)  // 构造器代理
        // 调用构造器代理之后，即可通过self访问该实例的属性
        print("--执行显式指定外部形参名的构造器--\(self.name)")
    }
    // 定义三个参数的构造器
    init(name: String , color: String , weight: Double)
    {
        self.init(name , color)  // 构造器代理
        self.weight = weight
    }
}
//var ap1 = Apple("红富士" , "粉红色")
//print("\(ap1.name)--->\(ap1.color)")
//var ap2 = Apple(appleName:"青苹果" , appleColor:"绿色")
//print("\(ap2.name)--->\(ap2.color)")
//var ap3 = Apple(name:"美国苹果" , color:"红色" , weight:0.45)




//可能失败的构造器

struct Cat {
    let name: String
    init?(name: String){
        //如果传入的name为空字符串，构造器失败，返回nil
        if name.isEmpty {
            return nil
        }
        self.name = name
    }
}

let c1 = Cat(name: "Ada")
if c1 != nil {
    print(c1!.name)
}

let cat = Cat(name: "Kitty")
print(cat == nil)


enum Season3 {
    case Spring, Summer, Autumn, Winter
    init!(name: Character){
//        根据传入的构造器参数选择相应的枚举成员
        switch name {
        case "S","s":
            self = .Spring
        case "U", "u":
            self = .Summer
        case "A", "a":
            self = .Autumn
        case "W", "w":
            self = .Winter
        // 如果传入其他参数，构造失败，返回nil。
        default:
            return nil
        }
    }
}
let s1 = Season3(name: "s")
if s1 != nil {
    print("Season实例构造成功！")
}
let s2 = Season3(name: "x")
print(s2 == nil)










